To launch the project just install:

	pip install numpy
	pip install scipy
	pip install matplotlib

Then launch nn.py