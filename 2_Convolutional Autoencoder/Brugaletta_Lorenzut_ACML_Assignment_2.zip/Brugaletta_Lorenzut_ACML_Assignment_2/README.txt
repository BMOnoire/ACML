To launch the project just install the requirements:

	pip install -r requirements.txt

Then launch main.py