To launch the project just install the libraries:

	pip install gym
	pip install numpy
	pip install matplotlib

Then launch main.py